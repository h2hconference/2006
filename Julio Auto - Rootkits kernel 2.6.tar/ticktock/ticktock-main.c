#include <linux/kernel.h>
#include <linux/module.h>
#include <asm-i386/unistd.h>
#include <linux/elf.h>
#include <linux/string.h>
#include <asm/uaccess.h>
#include <linux/vmalloc.h>

#include "libdis.h"

//#define TICKTOCK_DBG

typedef struct {
	unsigned short off1;
	unsigned short seg_sel;
	unsigned char constants, flags;
	unsigned short off2;
} __attribute__((packed)) interrupt_descriptor;

typedef struct {
	unsigned short limit;
	unsigned int base_addr;
} __attribute__((packed)) IDTR;

/* This is where our guessed system call table will be */
static unsigned int *ticktock_guessed_sct = NULL;

static asmlinkage long (*ticktock_old_init_module) (void __user *, unsigned long, const char __user *);

static asmlinkage long ticktock_init_module_hook (void __user *umod, unsigned long len, const char __user *uargs)
{
	Elf_Ehdr *ehdr;
	Elf_Shdr *shdrs;
	unsigned int i;
	unsigned int size;
	unsigned int total_size;
	unsigned char *ptr;

	if (!capable(CAP_SYS_MODULE))
		return -EPERM;
	
	if (len < sizeof(*ehdr))
		return -ENOEXEC;

	if (len > 64 * 1024 * 1024 || (ehdr = vmalloc(len)) == NULL)
		return -ENOMEM;

	if (copy_from_user(ehdr, umod, len) != 0) {
		vfree(ehdr);
		return -EFAULT;
	}

	if (memcmp (ehdr->e_ident, ELFMAG, 4) != 0 ||
		ehdr->e_type != ET_REL ||
		!elf_check_arch(ehdr) ||
		ehdr->e_shentsize != sizeof(*shdrs)) {

		vfree(ehdr);
		return -ENOEXEC;
	}

	if (len < ehdr->e_shoff + ehdr->e_shnum * sizeof(Elf_Shdr)) {
		printk(KERN_ERR "Module len %lu truncated\n", len);
		vfree(ehdr);
		return -ENOEXEC;
	}

	shdrs = (void *)ehdr + ehdr->e_shoff;

	for (i = 1; i < ehdr->e_shnum; i++) {
		if (shdrs[i].sh_type != SHT_PROGBITS ||
			!(shdrs[i].sh_flags & SHF_EXECINSTR))
			continue;
		
		size = 0;
		total_size = 0;
		ptr = (unsigned char *)ehdr + shdrs[i].sh_offset;

		do {
			size = ticktock_size_disasm(ptr,shdrs[i].sh_size-total_size);
		
			if (size > 2 && ptr[0] == 0x0F && ptr[1] == 0x01) {
				printk(KERN_ERR "Suspicious module insertion" \
						" attempt\n");
				return -EPERM;
			}
		

		total_size += size;
		ptr += size;
		} while (size);
	}

	return ticktock_old_init_module(umod, len, uargs);
}

int init_module()
{
	IDTR idtr;
	interrupt_descriptor *IDT;
	interrupt_descriptor *system_gate;
	unsigned char *sys_call_asm;
	int i;

	asm("sidt %0" : "=m" (idtr));

	#ifdef TICKTOCK_DBG
		printk("IDT limit: %d\n", idtr.limit);
		printk("IDT base address: 0x%08x\n", idtr.base_addr);
	#endif

	IDT = (interrupt_descriptor *) idtr.base_addr;
	system_gate = &IDT[0x80];

	#ifdef TICKTOCK_DBG
	 	printk("System call gate info:\n");
		printk("Address of descriptor: 0x%08x\n", (unsigned int) system_gate);
		printk("Segment selector: %hu\n", system_gate->seg_sel);
		printk("Offset[0...15]: %hu\n", system_gate->off1);
		printk("Offset[16...31]: %hu\n", system_gate->off2);
		printk("Assembled offset: 0x%08x\n", (system_gate->off2 << 16) |
							system_gate->off1);
		printk("Flags: %hu\n", system_gate->flags);
		printk("Constants: %hu\n\n", system_gate->constants);
	#endif

	sys_call_asm = (char *) ((system_gate->off2 << 16) | system_gate->off1);
	
	for (i = 0; i < 100; i++) {
		if (sys_call_asm[i] == (unsigned char) 0xff &&
		    sys_call_asm[i+1] == (unsigned char) 0x14 &&
		    sys_call_asm[i+2] == (unsigned char) 0x85)
			ticktock_guessed_sct = (unsigned int *) 
					*(unsigned int *) &sys_call_asm[i+3];

		#ifdef TICKTOCK_DBG
			printk("0x%02x ", sys_call_asm[i]);
		#endif
	}

	#ifdef TICKTOCK_DBG
		printk("\n");
	#endif

	if (!ticktock_guessed_sct) {
		#ifdef TICKTOCK_DBG
			printk("We flunked, go home. " \
				"This module won't be loaded. :(\n");
		#endif
		return -EPERM;
	}

	#ifdef TICKTOCK_DBG
		printk("Guessed system call table address: 0x%08x\n", 
			(unsigned int) ticktock_guessed_sct);
	#endif

	ticktock_old_init_module = (void *) ticktock_guessed_sct[__NR_init_module];
	ticktock_guessed_sct[__NR_init_module] = (unsigned int) ticktock_init_module_hook;

	return 0;
}

void cleanup_module()
{
	ticktock_guessed_sct[__NR_init_module] = (unsigned int) ticktock_old_init_module;
}
